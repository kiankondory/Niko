# Niko — Architecture and Product Decisions

Record durable decisions and their rationale here. Every new decision must include date, status, context, and consequences.

## ADR-001 — Shared Core

- Status: Accepted
- Decision: Domain models and use cases live in the shared Core.
- Rationale: Consistent behavior across mobile, wearables, widgets, and tests.
- Consequence: Platforms are adapters; independent domain logic is forbidden.

## ADR-002 — Offline-first event logging

- Status: Accepted
- Decision: Logs are stored locally first and synchronized through a queue.
- Rationale: QuickLog cannot depend on network availability; retry and idempotency are required.
- Consequence: Event IDs, sync status, migrations, and conflict policy must remain stable.

## ADR-003 — Localization from day one

- Status: Accepted
- Decision: Use resource/key-based localization with fallback and RTL/LTR support.
- Rationale: Support 15 languages without broad rewrites.
- Consequence: UI must not depend on source-language length, direction, or formatting rules.

## ADR-004 — Privacy-first AI

- Status: Accepted
- Decision: AI is opt-in, minimum-data, disableable, and non-diagnostic.
- Rationale: Behavioral and health-related data is sensitive; trust is a product requirement.
- Consequence: Guardrails, auditability, and a non-AI fallback are required.

## Decision template

```text
## ADR-XXX — Title
- Date:
- Status: Proposed | Accepted | Superseded
- Context:
- Decision:
- Alternatives considered:
- Consequences and trade-offs:
```

